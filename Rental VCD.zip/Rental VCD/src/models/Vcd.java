package models;

public class Vcd {
    private String no_vcd;
    private String judul;
    private String kategori;
    private String namaPencipta;
    private String namaPenerbit;
    private String tahunRilis;
    private String sinopsis;

    public String getNovcd() {
        return no_vcd;
    }

    public void setNovcd(String no_vcd) {
        this.no_vcd = no_vcd;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getNamaPencipta() {
        return namaPencipta;
    }

    public void setNamaPencipta(String namaPencipta) {
        this.namaPencipta = namaPencipta;
    }

    public String getNamaPenerbit() {
        return namaPenerbit;
    }

    public void setNamaPenerbit(String namaPenerbit) {
        this.namaPenerbit = namaPenerbit;
    }

    public String getTahunRilis() {
        return tahunRilis;
    }

    public void setTahunRilis(String tahunRilis) {
        this.tahunRilis = tahunRilis;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }
    
    
}
